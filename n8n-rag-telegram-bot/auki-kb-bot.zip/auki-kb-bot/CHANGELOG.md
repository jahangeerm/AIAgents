# Changelog

## v1.0.0 — Initial Release

### Telegram Bot Workflow
- Telegram trigger with command routing (/start, /help, /reset)
- RAG pipeline: OpenAI embeddings → pgvector similarity search → GPT-4o
- Conversation history stored per user in Supabase
- Anti-repetition and tone rules baked into system prompt
- Reply truncation at 4096 chars (Telegram limit)
- Deduplication guard on conversation history inserts (30s window)

### Knowledge Base Ingestion Workflow
- Google Drive polling trigger (hourly)
- PDF text extraction and 800-char overlapping chunking
- Clean re-ingestion: deletes old chunks before inserting new ones
- Per-chunk OpenAI embeddings stored as pgvector vectors in Supabase

### Bug Fixes (from development)
- Fixed duplicate message bug caused by Aggregate KB Results1 wiring to both
  Fetch Conversation History and Aggregate History simultaneously
- Fixed Aggregate History context loss after removing duplicate connection
- Extended history deduplication window from 10s to 30s
- Renamed misleading "HTTP Request2" node to "Vector Search KB"
