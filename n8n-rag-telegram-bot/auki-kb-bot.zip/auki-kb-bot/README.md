# Auki Knowledge Base Bot

A Telegram chatbot that answers questions about [Auki Labs](https://auki.com) and the Posemesh using RAG (Retrieval-Augmented Generation). Built with n8n, OpenAI, Supabase (pgvector), and Google Drive.

---

## How It Works

The project consists of two n8n workflows:

### 📨 Telegram Bot Workflow
Receives messages from Telegram, routes commands, and answers questions using vector search + GPT-4o.

```
Telegram → Parse Message → Command Router
                               ├── /start  → Welcome message
                               ├── /help   → Help message
                               ├── /reset  → Clear conversation history
                               └── [question] → Embed → Vector Search → Build Prompt → GPT-4o → Reply
```

### 📥 Knowledge Base Ingestion Workflow
Watches a Google Drive PDF, chunks it, embeds each chunk, and stores it in Supabase.

```
Google Drive Trigger → Download → Extract Text → Chunk → Delete Old → Embed → Insert into Supabase
```

---

## Stack

| Service | Purpose |
|---|---|
| [n8n](https://n8n.io) | Workflow automation |
| [Telegram Bot API](https://core.telegram.org/bots/api) | Chat interface |
| [OpenAI](https://platform.openai.com) | Embeddings (`text-embedding-3-small`) + Chat (`gpt-4o`) |
| [Supabase](https://supabase.com) | Postgres + pgvector for conversation history and knowledge base |
| [Google Drive](https://drive.google.com) | PDF knowledge base source |

---

## Setup

### Prerequisites
- n8n instance (self-hosted or cloud)
- OpenAI API key
- Telegram Bot token (via [@BotFather](https://t.me/botfather))
- Supabase project with pgvector enabled
- Google Drive with a PDF knowledge base file

### 1. Supabase — Create Tables

Run the SQL in [`supabase/schema.sql`](supabase/schema.sql) in your Supabase SQL editor.

### 2. n8n — Add Credentials

In your n8n instance, create the following credentials:

| Credential Name | Type | Notes |
|---|---|---|
| `Telegram account` | Telegram API | Your bot token from BotFather |
| `Postgres account (Supabase)` | Postgres | Supabase connection string |
| `OpenAI Header Auth account` | Header Auth | Header: `Authorization`, Value: `Bearer sk-...` |
| `Google Drive OAuth2 API` | Google OAuth2 | Scopes: Drive read |

### 3. n8n — Import Workflow

1. Open your n8n instance
2. Go to **Workflows → Import**
3. Upload `workflow/auki-kb-bot.json`
4. Reassign credentials on each node (n8n will prompt you)
5. In the **Google Drive Trigger** and **Download File** nodes, replace `YOUR_GOOGLE_DRIVE_FILE_ID` with your actual file ID
6. Activate both workflows

### 4. Set Your Telegram Webhook

n8n handles this automatically when you activate the Telegram Trigger node.

---

## Supabase Schema

See [`supabase/schema.sql`](supabase/schema.sql) for the full setup including pgvector extension, tables, and indexes.

---

## Commands

| Command | Description |
|---|---|
| `/start` | Introduction message |
| `/help` | Example questions |
| `/reset` | Clear your conversation history |

---

## Customising the Bot

The bot's personality, tone, and content rules are all defined in the **Build Prompt** node inside the workflow. Edit the `systemPrompt` string there to change how the bot responds.

---

## License

MIT — see [LICENSE](LICENSE)
