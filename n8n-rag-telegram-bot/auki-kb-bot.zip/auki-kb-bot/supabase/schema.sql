-- ============================================================
-- Auki KB Bot — Supabase Schema
-- Run this in your Supabase SQL editor before using the bot
-- ============================================================

-- Enable pgvector extension
create extension if not exists vector;

-- ------------------------------------------------------------
-- Knowledge Base Table
-- Stores chunked document embeddings for vector search
-- ------------------------------------------------------------
create table if not exists auki_knowledge (
  id           bigserial primary key,
  file_id      text        not null,
  file_name    text        not null,
  chunk_index  int         not null,
  content      text        not null,
  embedding    vector(1536),           -- text-embedding-3-small dimensions
  metadata     jsonb       default '{}'::jsonb,
  created_at   timestamptz default now()
);

-- Index for fast cosine similarity search
create index if not exists auki_knowledge_embedding_idx
  on auki_knowledge
  using ivfflat (embedding vector_cosine_ops)
  with (lists = 100);

-- Index for fast file-based deletion during re-ingestion
create index if not exists auki_knowledge_file_id_idx
  on auki_knowledge (file_id);

-- ------------------------------------------------------------
-- Conversation History Table
-- Stores per-user chat history for multi-turn context
-- ------------------------------------------------------------
create table if not exists auki_conversation_history (
  id         bigserial primary key,
  user_id    text        not null,
  role       text        not null check (role in ('user', 'assistant')),
  content    text        not null,
  created_at timestamptz default now()
);

-- Index for fast per-user history retrieval
create index if not exists auki_conversation_history_user_idx
  on auki_conversation_history (user_id, created_at asc);
